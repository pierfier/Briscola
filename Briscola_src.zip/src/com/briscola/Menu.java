package com.briscola;

public class Menu {
	
	void clearMenu(){
		
	}
	
	void startGame(){
		
	}
	
}
