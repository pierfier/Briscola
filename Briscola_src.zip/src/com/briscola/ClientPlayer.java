package com.briscola;

public class ClientPlayer {

}
