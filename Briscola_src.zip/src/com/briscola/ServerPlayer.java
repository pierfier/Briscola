package com.briscola;

public class ServerPlayer {
	
}
