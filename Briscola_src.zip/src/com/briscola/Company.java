package com.briscola;

public class Company {

}
