package com.briscola;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;

import android.app.Service;

public class NetworkManager {
	// this class monitors with the networking for this application

	// determines whether this phone
	// is the server phone
	boolean isServer;

	// sockets to enable communications
	ServerSocket serverSocket;
	//an array to have multiple connections
	Socket[] sockets;
	
	//determines when the server
	//is waiting for multiple clients
	boolean listening = true;
	
	//says if thread created a connection 
	//with a client
	boolean[] found = new boolean[4];
	
	//threads to wait for listeners
	Thread[] clientListeners = new Thread[4];

	//that way this variable can be
	//inner thread modified
	int listenerIndex = 0;
	
	// streams to allow for data interaction
	ObjectInputStream[] in;
	ObjectOutputStream[] out;

	private void enableStreams() {
		for (int i =0; i < sockets.length;i++){
			try {
				in[i] = new ObjectInputStream(sockets[i].getInputStream());
				out[i] = new ObjectOutputStream(sockets[i].getOutputStream());
			} catch (StreamCorruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void setupServer(){
		try {
			serverSocket = new ServerSocket(1919, 4);
		} catch (IOException e) {
			e.printStackTrace();
		}		
		
	}
	
	private void setupDefaultValues(){
		for (int i = 0; i < found.length; i++) {
			found[i] = false;
		}		
	}
	
	public void setupConnections () {
		for (int i = 0; i < clientListeners.length; i++) {
			clientListeners[i] = new Thread(){
				public void run (){
					int index = 0;
					index = listenerIndex;
					System.out.println(index);
					while (listening){
						try {
							sockets[index] = serverSocket.accept();
							found[index] = true;
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
			 	}				
			};
			listenerIndex += 1;
		}
		for (int i = 0; i < clientListeners.length; i++) {
			clientListeners[i].start();
		}
	}
	
	public void stopExtraClientListeners(){
				
	}
}