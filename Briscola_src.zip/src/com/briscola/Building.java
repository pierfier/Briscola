package com.briscola;

public class Building {

}
